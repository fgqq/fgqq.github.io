#!/bin/bash
git add --all
git commit -m "changes log"
git push -u origin main
